<?php
	$hostname = "sql.njit.edu";
	$username = "pk549";
	$project = "pk549";
	$password = "*Flameball168";
?>